CREATE TABLE Profiles (
    ProfileID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255),
    Age INT,
    Email VARCHAR(255),
    Gender ENUM('Male', 'Female', 'Other'),
    Relation VARCHAR(255)
);
